package com.example.myapp.iconnect;

import android.graphics.drawable.Drawable;

/**
 * Created by SandoxNgwenya on 10/5/2018.
 */

public class Item {
    CharSequence label; // Package Name
    CharSequence name; //Application Name
    Drawable icon;

}
